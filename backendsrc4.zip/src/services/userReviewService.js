const mongoose = require('mongoose');
const UserReview = require('../models/UserReview');
const Deal = require('../models/Deal');
const { AppError, NotFoundError, ForbiddenError, ConflictError, ValidationError } = require('../middleware/errorHandler');
const reviewStatsService = require('./reviewStatsService');

const COMPLETED_DEAL_STATUSES = ['confirmed', 'completed'];

function isSameId(a, b) {
  return a && b && a.toString() === b.toString();
}

function isCompletedDeal(deal) {
  if (!deal) return false;
  if (typeof deal.isReviewable === 'function') return deal.isReviewable();
  return COMPLETED_DEAL_STATUSES.includes(deal.status) || Boolean(deal.completedAt);
}

function validateReviewInput({ dealId, reviewerId, rating, text }) {
  if (!mongoose.Types.ObjectId.isValid(dealId)) {
    throw new ValidationError('شناسه معامله نامعتبر است', [{ field: 'dealId', message: 'Invalid deal id' }]);
  }

  if (!mongoose.Types.ObjectId.isValid(reviewerId)) {
    throw new ValidationError('شناسه کاربر نامعتبر است', [{ field: 'reviewerId', message: 'Invalid reviewer id' }]);
  }

  if (!Number.isInteger(Number(rating)) || Number(rating) < 1 || Number(rating) > 5) {
    throw new ValidationError('امتیاز باید عددی بین ۱ تا ۵ باشد', [{ field: 'rating', message: 'Rating must be between 1 and 5' }]);
  }

  if (!text || typeof text !== 'string' || text.trim().length < 3 || text.trim().length > 1000) {
    throw new ValidationError('متن نظر باید بین ۳ تا ۱۰۰۰ کاراکتر باشد', [{ field: 'text', message: 'Review text length is invalid' }]);
  }
}

function resolveReviewRoles(deal, reviewerId) {
  if (isSameId(deal.buyer, reviewerId)) {
    return {
      reviewerRole: 'buyer',
      revieweeRole: 'seller',
      reviewee: deal.seller
    };
  }

  if (isSameId(deal.seller, reviewerId)) {
    return {
      reviewerRole: 'seller',
      revieweeRole: 'buyer',
      reviewee: deal.buyer
    };
  }

  throw new ForbiddenError('فقط خریدار یا فروشنده همین معامله می‌تواند نظر ثبت کند');
}

async function ensureCanReview(deal, reviewerId) {
  if (!deal) {
    throw new NotFoundError('معامله یافت نشد');
  }

  if (!isCompletedDeal(deal)) {
    throw new AppError('ثبت نظر فقط پس از تکمیل معامله امکان‌پذیر است', 400, 'DEAL_NOT_COMPLETED');
  }

  const roles = resolveReviewRoles(deal, reviewerId);
  const existingReview = await UserReview.findOne({
    deal: deal._id,
    reviewer: reviewerId
  }).select('_id');

  if (existingReview) {
    throw new ConflictError('شما قبلاً برای این معامله نظر ثبت کرده‌اید');
  }

  return roles;
}

async function createReview({ dealId, reviewerId, rating, text }) {
  validateReviewInput({ dealId, reviewerId, rating, text });

  const deal = await Deal.findById(dealId);
  const roles = await ensureCanReview(deal, reviewerId);

  const review = await UserReview.create({
    buyer: deal.buyer,
    seller: deal.seller,
    reviewer: reviewerId,
    reviewee: roles.reviewee,
    reviewerRole: roles.reviewerRole,
    revieweeRole: roles.revieweeRole,
    text: text.trim(),
    rating: Number(rating),
    deal: deal._id,
    shipment: deal.shipping || null
  });

  await reviewStatsService.recalculateUserReviewStats(roles.reviewee);

  return UserReview.findById(review._id)
    .populate('reviewer', 'firstName lastName profileImage publicSlug publicProfile')
    .populate('reviewee', 'firstName lastName profileImage publicSlug publicProfile')
    .populate('deal', 'dealNumber title status completedAt');
}

async function getUserReviews({ userId, page = 1, limit = 10, rating }) {
  if (!mongoose.Types.ObjectId.isValid(userId)) {
    throw new ValidationError('شناسه کاربر نامعتبر است', [{ field: 'userId', message: 'Invalid user id' }]);
  }

  const parsedPage = Math.max(parseInt(page, 10) || 1, 1);
  const parsedLimit = Math.min(Math.max(parseInt(limit, 10) || 10, 1), 50);
  const query = {
    reviewee: userId,
    isVisible: true
  };

  if (rating) {
    const parsedRating = Number(rating);
    if (!Number.isInteger(parsedRating) || parsedRating < 1 || parsedRating > 5) {
      throw new ValidationError('فیلتر امتیاز نامعتبر است', [{ field: 'rating', message: 'Rating filter must be between 1 and 5' }]);
    }
    query.rating = parsedRating;
  }

  const [total, reviews] = await Promise.all([
    UserReview.countDocuments(query),
    UserReview.find(query)
      .sort({ createdAt: -1 })
      .skip((parsedPage - 1) * parsedLimit)
      .limit(parsedLimit)
      .populate('reviewer', 'firstName lastName profileImage publicSlug publicProfile')
      .populate('deal', 'dealNumber title status completedAt')
      .lean()
  ]);

  return {
    reviews,
    pagination: {
      total,
      page: parsedPage,
      limit: parsedLimit,
      pages: Math.ceil(total / parsedLimit),
      hasNext: parsedPage < Math.ceil(total / parsedLimit),
      hasPrev: parsedPage > 1
    }
  };
}

async function getReviewSummary(userId) {
  if (!mongoose.Types.ObjectId.isValid(userId)) {
    throw new ValidationError('شناسه کاربر نامعتبر است', [{ field: 'userId', message: 'Invalid user id' }]);
  }

  const stats = await reviewStatsService.getUserReviewStats(userId);

  return {
    averageRating: stats.averageRating,
    reviewsCount: stats.reviewsCount,
    distribution: {
      5: stats.fiveStarsCount,
      4: stats.fourStarsCount,
      3: stats.threeStarsCount,
      2: stats.twoStarsCount,
      1: stats.oneStarCount
    }
  };
}

async function getDealReviewEligibility({ dealId, userId }) {
  if (!mongoose.Types.ObjectId.isValid(dealId)) {
    throw new ValidationError('شناسه معامله نامعتبر است', [{ field: 'dealId', message: 'Invalid deal id' }]);
  }

  const deal = await Deal.findById(dealId)
    .populate('buyer', 'firstName lastName profileImage publicSlug publicProfile')
    .populate('seller', 'firstName lastName profileImage publicSlug publicProfile');

  if (!deal) {
    throw new NotFoundError('معامله یافت نشد');
  }

  let roles;
  try {
    roles = resolveReviewRoles(deal, userId);
  } catch (error) {
    return {
      canReview: false,
      reason: 'not_deal_participant',
      alreadyReviewed: false,
      reviewee: null,
      reviewerRole: null,
      revieweeRole: null
    };
  }

  const existingReview = await UserReview.findOne({
    deal: deal._id,
    reviewer: userId
  }).select('_id');

  if (!isCompletedDeal(deal)) {
    return {
      canReview: false,
      reason: 'deal_not_completed',
      alreadyReviewed: Boolean(existingReview),
      reviewee: roles.reviewee,
      reviewerRole: roles.reviewerRole,
      revieweeRole: roles.revieweeRole
    };
  }

  if (existingReview) {
    return {
      canReview: false,
      reason: 'already_reviewed',
      alreadyReviewed: true,
      reviewee: roles.reviewee,
      reviewerRole: roles.reviewerRole,
      revieweeRole: roles.revieweeRole
    };
  }

  return {
    canReview: true,
    reason: null,
    alreadyReviewed: false,
    reviewee: roles.reviewee,
    reviewerRole: roles.reviewerRole,
    revieweeRole: roles.revieweeRole
  };
}

module.exports = {
  createReview,
  getUserReviews,
  getReviewSummary,
  getDealReviewEligibility,
  resolveReviewRoles,
  ensureCanReview
};
