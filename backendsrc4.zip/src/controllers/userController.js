const User = require('../models/User');
const VerificationRequest = require('../models/VerificationRequest');
const Subscription = require('../models/Subscription');
const Wallet = require('../models/Wallet');
const { asyncHandler } = require('../middleware/errorHandler');
const response = require('../utils/responseFormatter');
const fileUploadService = require('../services/fileUploadService');
const { paginate, paginationResponse } = require('../utils/helpers');

// @desc    Get user profile
// @route   GET /api/users/me
// @access  Private
exports.getProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  const subscription = await Subscription.findOne({
    user: req.user._id,
    status: 'active'
  });
  const wallet = await Wallet.getOrCreateWallet(req.user._id);

  return response.success(res, {
    user: user.toObject(),
    subscription,
    wallet: {
      balance: wallet.balances.IRR.available,
      blocked: wallet.balances.IRR.blocked
    }
  });
});

// @desc    Update user profile
// @route   PUT /api/users/me
// @access  Private
exports.updateProfile = asyncHandler(async (req, res) => {
  const allowedFields = [
    'firstName', 'lastName', 'email', 'about', 'website',
    'location', 'settings', 'showPhoneToSellers', 'wantsCollaboration', 'sellerStatus'
  ];

  const updates = {};
  allowedFields.forEach(field => {
    if (req.body[field] !== undefined) {
      updates[field] = req.body[field];
    }
  });

  // Handle nested location object
  if (req.body.province || req.body.city || req.body.address) {
    updates.location = {
      ...updates.location,
      province: req.body.province || req.body.location?.province,
      city: req.body.city || req.body.location?.city,
      address: req.body.address || req.body.location?.address,
    };
  }

  const user = await User.findByIdAndUpdate(
    req.user._id,
    updates,
    { new: true, runValidators: true }
  );

  // Check if profile is complete enough for level 1
  if (user.level === 0 && user.firstName && user.lastName && user.location?.province) {
    user.level = 1;
    user.levelStatus = 'approved';
    await user.save();
  }

  return response.success(res, { user }, 'پروفایل با موفقیت به‌روزرسانی شد');
});

// @desc    Upload profile image
// @route   POST /api/users/me/profile-image
// @access  Private
exports.uploadProfileImage = asyncHandler(async (req, res) => {
  if (!req.file) {
    return response.error(res, 'تصویر الزامی است', 400);
  }

  const result = await fileUploadService.uploadProfileImage(req.file);

  // Delete old image if exists
  if (req.user.profileImage) {
    // Extract publicId from URL and delete
  }

  const user = await User.findByIdAndUpdate(
    req.user._id,
    { profileImage: result.url },
    { new: true }
  );

  return response.success(res, { 
    profileImage: result.url,
    user 
  }, 'تصویر پروفایل با موفقیت آپلود شد');
});

// @desc    Get public profile
// @route   GET /api/users/:id/public
// @access  Public
exports.getPublicProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);

  if (!user) {
    return response.notFound(res, 'کاربر یافت نشد');
  }

  return response.success(res, { 
    profile: user.getPublicProfile() 
  });
});

// @desc    Request level up
// @route   POST /api/users/level-up
// @access  Private
exports.requestLevelUp = asyncHandler(async (req, res) => {
  const { targetLevel } = req.body;
  const currentLevel = req.user.level;

  if (targetLevel <= currentLevel) {
    return response.error(res, 'سطح هدف باید بالاتر از سطح فعلی باشد', 400);
  }

  if (targetLevel > currentLevel + 1) {
    return response.error(res, 'باید مراحل را به ترتیب طی کنید', 400);
  }

  // Check for existing pending request
  const existingRequest = await VerificationRequest.findOne({
    user: req.user._id,
    targetLevel,
    status: { $in: ['pending', 'in_review'] }
  });

  if (existingRequest) {
    return response.error(res, 'درخواست قبلی شما در حال بررسی است', 400);
  }

  const verificationRequest = new VerificationRequest({
    user: req.user._id,
    targetLevel,
    currentLevel
  });

  await verificationRequest.save();

  // Update user level status
  await User.findByIdAndUpdate(req.user._id, {
    levelStatus: 'pending'
  });

  return response.created(res, { 
    requestId: verificationRequest._id 
  }, 'درخواست ارتقای سطح ثبت شد');
});

// @desc    Upload verification document
// @route   POST /api/users/upload-document
// @access  Private
exports.uploadDocument = asyncHandler(async (req, res) => {
  const { docType } = req.body;

  if (!req.file) {
    return response.error(res, 'فایل الزامی است', 400);
  }

  const validDocTypes = [
    'nationalCard', 'birthCertificate', 'selfieWithCard',
    'businessLicense', 'businessPhotos', 'catalog', 'bankCardImage'
  ];

  if (!validDocTypes.includes(docType)) {
    return response.error(res, 'نوع سند نامعتبر است', 400);
  }

  const result = await fileUploadService.uploadVerificationDocument(
    req.file, req.user._id, docType
  );

  // Find or create verification request
  let verificationRequest = await VerificationRequest.findOne({
    user: req.user._id,
    status: { $in: ['pending', 'in_review', 'requires_resubmit'] }
  });

  if (!verificationRequest) {
    return response.error(res, 'ابتدا درخواست ارتقای سطح ثبت کنید', 400);
  }

  // Update document in request
  if (docType === 'businessPhotos') {
    if (!verificationRequest.documents.businessPhotos) {
      verificationRequest.documents.businessPhotos = [];
    }
    verificationRequest.documents.businessPhotos.push({
      url: result.url,
      publicId: result.publicId,
      uploadedAt: new Date()
    });
  } else {
    verificationRequest.documents[docType] = {
      url: result.url,
      publicId: result.publicId,
      uploadedAt: new Date()
    };
  }

  await verificationRequest.save();

  return response.success(res, {
    url: result.url,
    docType
  }, 'سند با موفقیت آپلود شد');
});

// @desc    Submit additional info for verification
// @route   POST /api/users/verification-info
// @access  Private
exports.submitVerificationInfo = asyncHandler(async (req, res) => {
  const verificationRequest = await VerificationRequest.findOne({
    user: req.user._id,
    status: { $in: ['pending', 'in_review', 'requires_resubmit'] }
  });

  if (!verificationRequest) {
    return response.error(res, 'درخواست احراز هویت یافت نشد', 400);
  }

  // Update additional info
  const allowedFields = [
    'nationalCode', 'birthDate', 'fatherName',
    'businessName', 'businessType', 'businessAddress', 'employeeCount', 'yearEstablished',
    'shaba', 'bankName', 'cardNumber', 'accountHolder'
  ];

  allowedFields.forEach(field => {
    if (req.body[field] !== undefined) {
      verificationRequest.additionalInfo[field] = req.body[field];
    }
  });

  await verificationRequest.save();

  return response.success(res, { 
    request: verificationRequest 
  }, 'اطلاعات با موفقیت ثبت شد');
});

// @desc    Get user documents
// @route   GET /api/users/documents
// @access  Private
exports.getDocuments = asyncHandler(async (req, res) => {
  const verificationRequests = await VerificationRequest.find({
    user: req.user._id
  }).sort({ createdAt: -1 });

  return response.success(res, { 
    documents: req.user.documents,
    verificationRequests 
  });
});

// @desc    Get user activity history
// @route   GET /api/users/activity
// @access  Private
exports.getActivity = asyncHandler(async (req, res) => {
  const { page, limit } = paginate(req.query.page, req.query.limit);

  // This would aggregate from various collections
  // For now, return basic stats
  const stats = req.user.stats;

  return response.success(res, { stats });
});

// @desc    Search users (admin)
// @route   GET /api/users/search
// @access  Admin
exports.searchUsers = asyncHandler(async (req, res) => {
  const { q, page = 1, limit = 20 } = req.query;

  const query = {};
  if (q) {
    query.$or = [
      { phone: { $regex: q, $options: 'i' } },
      { firstName: { $regex: q, $options: 'i' } },
      { lastName: { $regex: q, $options: 'i' } },
      { email: { $regex: q, $options: 'i' } }
    ];
  }

  const total = await User.countDocuments(query);
  const users = await User.find(query)
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(parseInt(limit))
    .select('-password -refreshToken');

  return response.paginated(res, users, paginationResponse(total, page, limit));
});
